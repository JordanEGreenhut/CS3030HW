"""
Homework 7, Exercise 3
Jordan Greenhut
10/20/2019
# This program downloads all the images of the query from imgur.com
"""
import requests, webbrowser, sys
from bs4 import BeautifulSoup
from urllib.request import urlretrieve

def filterHTTP(link):
    if '//i.imgur.com' in link:                                 #matching the required format of imgur image urls
        return True
    return False


def getURLs(html):
    soup = BeautifulSoup(html, 'html.parser')                   #parsing html using BeautifulSoup
    allATags = soup.select('img[src]')                          #selecting all <img> tags with src attribute
    allLinks = []
    for link in soup.find_all('img'):
        allLinks.append(link.get('src'))                        #adding all links to a list
    useFulLinks = filter(filterHTTP, allLinks)                  #filtering useless urls
    return list(useFulLinks)                                    #returning only useful urls


def imageDownload(query):
    with requests.session() as c:
        url = 'https://imgur.com/search/score?q=' + query       #preparing the url to request
        userAgent = "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11(KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11"
        headers = {'User-Agent': userAgent}
        res = requests.get(url, headers=headers)                #requesting the url

        links = getURLs(res.text)                               #extracting all useful urls from the html recieved
        i=1
        for x in links:
            x = 'https:' + x
            urlretrieve(x, query + str(i) + ".jpg")             #downloading all images found
            i+=1

if __name__ == '__main__':
    if len(sys.argv) <=1:
        print ("Enter query to search")                         #if no argument is passed
    else:
        query = ""
        for i in sys.argv[1:]:
            query = query + " " + i                             #concatenating all words passed as argument to make one query

        query = query[1:]                                       #removing the first extra space
        imageDownload(query)
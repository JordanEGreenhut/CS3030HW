"""
Homework 7, Exercise 4
Jordan Greenhut
10/20/2019
This program scrapes weather.gov for 10 cities.
It uses a queue and threading module with 5 threads.
"""
import logging
import threading
import time
import requests
from bs4 import BeautifulSoup


#function to be passed in threads
def hello(name, url1, city1, url2, city2):
    # City 1
    #requested url and get HTML page in response which is later parsed by beautifulsoup4
    response = requests.get(url1)
    soup = BeautifulSoup(response.text, 'html.parser')
    string = ""
    try:
        string = soup.find(class_="short-desc").text
    except:
        string = soup.find(class_="forecast-text").text
    # Check the climate condition on the basis of words.
    if "rain" in string or "cloud" in string or "flood" in string:
        logging.info("City %s: It could rain. Pack an umbrella today.", city1)
    elif "snow" in string or "cold" in string:
        logging.info("City %s: It's cold outside. Pack an extra jacket today.", city1)
    else:
        logging.info("City %s: Good to go outside.", city1)
    
    # City 2
    #requested url and get HTML page in response which is later parsed by beautifulsoup4
    response = requests.get(url2)
    soup = BeautifulSoup(response.text, 'html.parser')
    try:
        string = soup.find(class_="short-desc").text
    except:
        string = soup.find(class_="forecast-text").text 
    # Check the climate condition on the basis of words. 
    if "rain" in string or "cloud" in string or "flood" in string:
        logging.info("City %s: It could rain. Pack an umbrella today.", city2)
    elif "snow" in string or "cold" in string:
        logging.info("City %s: It's cold outside. Pack an extra jacket today.", city2)
    else:
        logging.info("City %s: Good to go outside.", city2)
        
# URL's corresponding to every city        
urls = ["https://forecast.weather.gov/MapClick.php?lat=38.8335&lon=-104.8218#.XarUj_fhWb8", "https://forecast.weather.gov/MapClick.php?lat=39.74&lon=-104.992#.XarUtvfhWb8", "https://forecast.weather.gov/MapClick.php?lat=25.7748&lon=-80.1977#.XarU0_fhWb8", "https://forecast.weather.gov/MapClick.php?lat=37.7771&lon=-122.4196#.XarVAffhWb8", "https://forecast.weather.gov/MapClick.php?lat=32.7157&lon=-117.1617#.XarUj_fhWb8", "https://forecast.weather.gov/MapClick.php?lat=34.0535&lon=-118.2453#.XarVOPfhWb8", "https://forecast.weather.gov/MapClick.php?lat=40.71455000000003&lon=-74.00713999999994#.XarUj_fhWb8", "https://forecast.weather.gov/MapClick.php?zoneid=NMZ219&zflg=1", "https://forecast.weather.gov/MapClick.php?lat=38.8904&lon=-77.032#.XarVjffhWb8", "https://forecast.weather.gov/MapClick.php?lat=29.9537&lon=-90.0777#.XarVq_fhWb8"]    
city = ["Colorado Springs", "Denver", "Miami", "San Francisco", "San Diego", "Los Angeles", "New York", "Albuquerque", "Washington", "New Orleans"]

# Logging information format
format = "%(asctime)s: %(message)s"
logging.basicConfig(format=format, level=logging.INFO, datefmt="%H:%M:%S")
i=1


threads = []
for i in range(0,len(urls),2):
    # single thread is accepting 2 URL's, thus in total for 10 URL's, we have 5 threads.
    x = threading.Thread(target=hello, args=(i, urls[i-1], city[i-1], urls[i], city[i]))
    x.start()
    threads.append(x)

for x in threads:
    # Waiting for other threads to end their individual work.
    x.join()

#Homework 5, Exercise 4
#Jordan Eric Greenhut
#10/6/2019
#This is the strong password detection
#Every password must meet a standard for strong passwords
#if the password is strong, then the if statement will report the password
#as strong
import re
#input for password
password=input("Enter password to test: ")
#password parameters to ensure the password matches
if re.match(r'[A-Za-z0-9]{8,}',password) and len(re.findall(r'[A-Z]{1,}',password))>0 and len(re.findall(r'[a-z]{1,}',password))>0 and len(re.findall(r'[0-9]{1,}',password))>0:
    #print valid password if the password is correct
    print("Valid Password")
else:
    #print invalid password if the password is not correct
    print("Invalid Password")
#Homework 5, Exercise 3
#Jordan Eric Greenhut
#10/6/2019
#This is the phone number and email address extractor
#The program scrapes a website for text, phone numbers, and email adresses
import pyperclip
#python module to copy/paste from clipboard
import re
#regex library

doc=pyperclip.paste()
#copying document from clipboard
x=re.findall("([0-9]{3}-[0-9]{3}-[0-9]{4}|\([0-9]{3}\) [0-9]{3}-[0-9]{4})",doc)
#regex to find all USA phone numbers.
y=re.findall(r"([A-Za-z0-9]+[\s]*\[at\][\s]*[A-Za-z0-9]+|[A-Za-z0-9]+@[A-Za-z0-9]+\.[a-zA-Z]*)", doc)
#regex to find all email ids.
z="Phone numbers:\n"+"\n". join (a for a in x ) + "\n\nEmail ids:\n"+"\n".join(b for b in y)
#adding all phone numbers and emails into a single document
pyperclip.copy(z)
#pasting the document to clipboard again
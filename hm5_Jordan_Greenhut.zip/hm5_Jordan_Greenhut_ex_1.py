#Homework 5, Exercise 1
#Jordan Eric Greenhut
#10/6/2019
#This is the slow down decorator program. The program imports time
#so it can use the time.sleep() function. The program uses a default value
#of 1 second
import time
#time module is imported so that we can use sleep function
def slowdown(func,rate=1):
    #rate arguement is used to control the time after which the called function is executed
    def wrap():
        time.sleep(rate)
        func()
        #function test is invoked using this function
    return wrap @slowdown
#decorator slowDown is used which we defined earlier
def test():
    #function which we want to execute after a period of time
    print("Sorry.....I'm late")
test()
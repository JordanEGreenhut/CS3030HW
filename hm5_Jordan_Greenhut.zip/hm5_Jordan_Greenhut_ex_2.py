#Homework 5, Exercise 4
#Jordan Eric Greenhut
#10/6/2019
#This is the fibonacci sequence program
#The program uses recursion to call the sequence
#it uses a dictionary to maintain the n values and fib(n) values
#if you do not use the cache, then the run time is much longer
#the way this is written allows the computer to not recalculate
#values that it has already calculated
#help from https://codereview.stackexchange.com/questions/95554/fibonacci-sum-with-memoization
#function definition
def fib(n):
    #if the number has already been computed, return the number
    if n in fib.cache:
        return fib.cache[n]
    ret = fib(n-2) + fib(n-1)
    fib.cache[n] = ret
    return ret
#fibonacci sequence with the n value and its fib value
fib.cache = {0: 1, 1: 1}
class Memorize(object):
    def __init__(self, func):
        self.func = func
        self.cache = {}
    def __call__(self, *args):
        if args in self.cache:
            #return the value if it exists already
            return self.cache[args]
        ret = self.func(*args)
        self.cache[args] = ret
        return ret
#recursive call for fibonacci
def fib(n):
    if n < 2:
        return 1
    return fib(n-2) + fib(n-1)